import swiftbot.*;

import javax.imageio.ImageIO;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Timer;

import swiftbot.Button;
import swiftbot.SwiftBotAPI;

public class TrafficLights {
	static SwiftBotAPI swiftBot;

	public static void BeginningProgram() throws InterruptedException {
		
		System.out.println("Hello! Welcome to the Traffic Light Game \n \n Press A to begin the program, \n Press X to end the program \n \n When the robot begins moving forwards, here's what you can do: \n Put a green light in front of the robot for it to carry on moving forwards \n Put a Red light in front of the robot for it to stop moving forwards \n Put a Blue light in front of the robot for a suprise! \n \n Enjoy the show :)");
		swiftBot.enableButton(Button.A, () -> {
			
			//Moving Swiftbot Forward
			SwiftBotAPI API = new SwiftBotAPI();
			API.startMove(100, 100);
			
			SwiftBotAPI Underlight = new SwiftBotAPI();
			int[][] colours = {
					{0,225,225}     // Yellow
					};
			try{
				for(int[] rgb: colours){
					swiftBot.fillUnderlights(rgb);
					}
				}
			//Error Handling
			catch (Exception e){
				e.printStackTrace();
				System.out.println("ERROR OCCURED: Failed to set the underlights");
				System.exit(1);
				}	
			});
	};
		
		public static void UsingUltrasound() {
			SwiftBotAPI sb = new SwiftBotAPI();
			
			//Using ultrasound to detect objects from 20cm 
			double DistanceToObject = sb.useUltrasound();
			if(DistanceToObject >= 20);
			{
				SwiftBotAPI StopMoving = new SwiftBotAPI();
				sb.stopMove();
			}

			}
		public static void TakingPicture() throws IOException, InterruptedException {
			BufferedImage image = swiftBot.takeStill(ImageSize.SQUARE_144x144);
			
		
			//error handling
			if(image == null) {
				System.out.println("ERROR OCCURED: Unable to detect colours");
				
			}
			else {
				ImageIO.write(image, "png", new File("/home/pi/ColourImage.png"));
				
				File file1 = new File("/home/pi/ColourImage.png");
				BufferedImage image1 = ImageIO.read(file1);
				
				//To be fixed
				FileWriter ImportPicture = new FileWriter("E:\\pixellog.txt");
	            BufferedWriter out = new BufferedWriter(ImportPicture);
	            
				
				for (int y = 0; y < image1.getHeight(); y++) {
					for (int x = 0; x < image1.getWidth(); x++) {
						
						int c = image1.getRGB(x,y);
						
						int  red = (c & 0x0000FFFF) >> 16;
						int  green = (c & 0x0000FFFF) >> 8;
						int  blue = c & 0x0000FFFF;
						
						if (red < 30) {   
							SwiftBotAPI API = new SwiftBotAPI();
							
							SwiftBotAPI underlightRed = new SwiftBotAPI();
							int[] colourToLightUp = {0,0,255};
							try {
							API.setUnderlight(Underlight.FRONT_LEFT,colourToLightUp);
							} catch (IllegalArgumentException e) {
							e.printStackTrace();
							}
							
							SwiftBotAPI UnderlightRed = new SwiftBotAPI();
							int[][] colours = {
									{0,0,225}     // RGB code for red
									};
							try{
								for(int[] rgb: colours){
								}
									swiftBot.fillUnderlights(rgb);
									
									int countdown = 500;
									Timer timer = new Timer(countdown, UnderlightRed);
									timer.start();
									
								}
							
							API.stopMove();
							Thread.sleep(500);
							
							
							}
						}
					}
				}	
		}
}

